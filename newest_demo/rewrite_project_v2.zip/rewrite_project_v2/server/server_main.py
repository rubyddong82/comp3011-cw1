from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional
from wsgiref.simple_server import make_server

from django.conf import settings
from django.core.wsgi import get_wsgi_application
from django.http import HttpRequest, JsonResponse
from django.urls import path
from django.views.decorators.csrf import csrf_exempt

CURRENT_FILE = Path(__file__).resolve()
SERVER_DIR = CURRENT_FILE.parent
PROJECT_ROOT = SERVER_DIR.parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SERVER_DIR) not in sys.path:
    sys.path.insert(0, str(SERVER_DIR))

try:
    from db import (
        DBError,
        DatasetNotRegisteredError,
        DatabaseManager,
        InvalidIdentifierError,
        RowNotFoundError,
        ValidationError,
    )
except ImportError:
    from server.db import (
        DBError,
        DatasetNotRegisteredError,
        DatabaseManager,
        InvalidIdentifierError,
        RowNotFoundError,
        ValidationError,
    )


DB_PATH = str((SERVER_DIR / "imdb.db").resolve())
db = DatabaseManager(DB_PATH)


def configure_django() -> None:
    if settings.configured:
        return
    settings.configure(
        DEBUG=True,
        SECRET_KEY="dev-secret-key-change-me",
        ROOT_URLCONF=__name__,
        ALLOWED_HOSTS=["*"],
        MIDDLEWARE=["django.middleware.common.CommonMiddleware"],
        INSTALLED_APPS=["django.contrib.contenttypes"],
        TEMPLATES=[],
        USE_TZ=True,
    )


configure_django()


def parse_json_body(request: HttpRequest) -> Dict[str, Any]:
    if not request.body:
        return {}
    try:
        return json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise ValidationError("Request body must be valid JSON.") from exc


def success(data: Dict[str, Any], status: int = 200) -> JsonResponse:
    return JsonResponse({"ok": True, "data": data}, status=status)


def failure(
    message: str,
    *,
    error_type: str = "server_error",
    status: int = 400,
    extra: Optional[Dict[str, Any]] = None,
) -> JsonResponse:
    payload = {"ok": False, "error": {"type": error_type, "message": message}}
    if extra:
        payload["error"]["details"] = extra
    return JsonResponse(payload, status=status)


def handle_db_error(exc: Exception) -> JsonResponse:
    if isinstance(exc, DatasetNotRegisteredError):
        return failure(str(exc), error_type="dataset_not_registered", status=404)
    if isinstance(exc, RowNotFoundError):
        return failure(str(exc), error_type="row_not_found", status=404)
    if isinstance(exc, (ValidationError, InvalidIdentifierError)):
        return failure(str(exc), error_type="validation_error", status=400)
    if isinstance(exc, DBError):
        return failure(str(exc), error_type="database_error", status=500)
    return failure(str(exc), error_type="server_error", status=500)


@csrf_exempt
def health(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return failure("Method not allowed.", error_type="method_not_allowed", status=405)
    try:
        datasets = db.get_datasets()
    except Exception:
        datasets = []
    return success({"service": "dataset-api", "db_path": DB_PATH, "datasets": datasets})


@csrf_exempt
def list_datasets(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return failure("Method not allowed.", error_type="method_not_allowed", status=405)
    try:
        return success({"datasets": db.get_datasets()})
    except Exception as exc:
        return handle_db_error(exc)


@csrf_exempt
def get_dataset_query_config(request: HttpRequest, dataset_name: str) -> JsonResponse:
    if request.method != "GET":
        return failure("Method not allowed.", error_type="method_not_allowed", status=405)
    try:
        return success(db.get_query_config(dataset_name))
    except Exception as exc:
        return handle_db_error(exc)


@csrf_exempt
def get_filter_choices(request: HttpRequest, dataset_name: str, column_name: str) -> JsonResponse:
    if request.method != "GET":
        return failure("Method not allowed.", error_type="method_not_allowed", status=405)
    try:
        label_search = request.GET.get("label_search") or None
        bucket_count = int(request.GET.get("bucket_count", "5"))
        data = db.get_filter_choices(
            dataset_name,
            column_name,
            label_search=label_search,
            bucket_count=bucket_count,
        )
        return success(data)
    except Exception as exc:
        return handle_db_error(exc)


@csrf_exempt
def query_rows(request: HttpRequest, dataset_name: str) -> JsonResponse:
    if request.method != "POST":
        return failure("Method not allowed.", error_type="method_not_allowed", status=405)
    try:
        body = parse_json_body(request)
        data = db.query_rows(
            dataset_name,
            search_text=body.get("search_text"),
            filters=body.get("filters", []),
            limit=int(body.get("limit", 20)),
            offset=int(body.get("offset", 0)),
        )
        return success(data)
    except Exception as exc:
        return handle_db_error(exc)


@csrf_exempt
def create_row(request: HttpRequest, dataset_name: str) -> JsonResponse:
    if request.method != "POST":
        return failure("Method not allowed.", error_type="method_not_allowed", status=405)
    try:
        body = parse_json_body(request)
        data = db.create_row(dataset_name, body.get("values", {}))
        return success(data, status=201)
    except Exception as exc:
        return handle_db_error(exc)


@csrf_exempt
def row_detail(request: HttpRequest, dataset_name: str, row_id: str) -> JsonResponse:
    if request.method == "GET":
        try:
            query_token = request.GET.get("query_token") or None
            return success(db.get_row_detail(dataset_name, row_id, query_token=query_token))
        except Exception as exc:
            return handle_db_error(exc)
    if request.method == "PUT":
        try:
            body = parse_json_body(request)
            return success(db.update_row(dataset_name, row_id, body.get("values", {})))
        except Exception as exc:
            return handle_db_error(exc)
    if request.method == "DELETE":
        try:
            return success(db.delete_row(dataset_name, row_id))
        except Exception as exc:
            return handle_db_error(exc)
    return failure("Method not allowed.", error_type="method_not_allowed", status=405)


urlpatterns = [
    path("health", health),
    path("api/datasets", list_datasets),
    path("api/datasets/<str:dataset_name>/query-config", get_dataset_query_config),
    path("api/datasets/<str:dataset_name>/filters/<str:column_name>/choices", get_filter_choices),
    path("api/datasets/<str:dataset_name>/rows/query", query_rows),
    path("api/datasets/<str:dataset_name>/rows", create_row),
    path("api/datasets/<str:dataset_name>/rows/<str:row_id>", row_detail),
]

application = get_wsgi_application()


def main(host: str = "127.0.0.1", port: int = 8000) -> None:
    print(f"[server_main] serving on http://{host}:{port}")
    print(f"[server_main] using database {DB_PATH}")
    httpd = make_server(host, port, application)
    httpd.serve_forever()


if __name__ == "__main__":
    main(host=os.environ.get("APP_HOST", "127.0.0.1"), port=int(os.environ.get("APP_PORT", "8000")))
